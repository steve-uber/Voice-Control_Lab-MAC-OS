# Voice Clone Lab — Apple Silicon (M1/M2/M3) Installation Guide

This is a macOS-optimized fork with full support for Apple Silicon Macs running Metal (MPS) acceleration. Training on M3 is slower than RTX 4090 but practical with reasonable batch sizes.

## System Requirements

- **macOS 12.3+** (Metal/MPS support)
- **Apple Silicon Mac** (M1, M2, M3, M3 Max, etc.)
- **Python ≥ 3.10** (3.12 recommended)
- **8 GB unified memory minimum** (16 GB+ recommended for training)
- **30 GB free disk space** (for models and checkpoints)

### Performance Expectations on Apple Silicon

| Chip | Training Speed | Generation | Notes |
|------|---|---|---|
| M1 | ~2–3x slower than RTX 3090 | Real-time | Batch size 1–2 |
| M2 | ~1.5–2x slower than RTX 3090 | Real-time | Batch size 2–4 |
| M3/M3 Max | ~1–1.5x slower than RTX 3090 | Real-time | Batch size 4–8 (Max) |

Slower training is acceptable for voice cloning—fine-tuning typically takes 30–90 minutes, even on M1.

## Installation Steps

### 1. Install Homebrew (if needed)

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### 2. Install Dependencies via Homebrew

```bash
# Core dependencies
brew install python@3.12 ffmpeg git

# Verify installations
python3 --version  # should be 3.12.x
ffmpeg -version    # should show version
```

### 3. Create a Python Virtual Environment

```bash
# Create a dedicated virtual environment
python3.12 -m venv ~/.venv/voice-clone-lab
source ~/.venv/voice-clone-lab/bin/activate

# Upgrade pip, setuptools, wheel
pip install --upgrade pip setuptools wheel
```

### 4. Install PyTorch with Metal Support

**This is critical.** Use the official Metal-optimized PyTorch build:

```bash
# Install PyTorch with Metal (MPS) support for Apple Silicon
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cpu

# Verify Metal support
python3 -c "import torch; print('Metal available:', torch.backends.mps.is_available())"
# Should print: Metal available: True
```

If you see `Metal available: False`, your PyTorch installation doesn't have Metal support—**reinstall using the command above**.

### 5. Clone or Download This Repository

```bash
git clone https://github.com/tetsuo-ai/voice_clone_lab.git
cd voice_clone_lab
```

### 6. Install Voice Clone Lab

```bash
# Activate virtual environment
source ~/.venv/voice-clone-lab/bin/activate

# Install the package with UI
pip install -e '.[ui]'

# Download Qwen3-TTS and base weights (~4 GB)
vcl setup --download

# Verify system readiness
vcl check
```

**Expected output from `vcl check`:**
```
[OK]   python           3.12.x
[OK]   ffmpeg           /opt/homebrew/bin/ffmpeg
[OK]   torch            X.XX.X (Metal/MPS for Apple Silicon)
[OK]   Metal (MPS)      Available for GPU acceleration
[OK]   GPU              arm64 — Unified memory (faster than separate VRAM)
[OK]   disk free        XXX.X GB free at project root
```

If you see any `[FAIL]` items, fix them before proceeding.

### 7. Optional: Install Extra Features

```bash
# For YouTube URL support:
pip install yt-dlp

# For better transcription (word-level timestamps):
pip install whisperx

# For audio denoising (optional but recommended):
pip install noisereduce

# For development/testing:
pip install pytest
```

## Quick Start

### Train Your Voice

```bash
# Activate virtual environment
source ~/.venv/voice-clone-lab/bin/activate

# 1. Provide audio (5–15 minutes of your voice)
#    Option A: Local file
vcl run --speaker myname --input ~/Recordings/me.wav

#    Option B: YouTube URL
vcl run --speaker myname --input "https://www.youtube.com/watch?v=..."

# 2. Review transcripts (fix any errors)
vcl transcribe --speaker myname --review

#    ...edit data/voices/myname/transcripts/transcripts_review.tsv...
#    Then apply corrections:
vcl transcribe --speaker myname --apply-review --force

# 3. Prepare and train
vcl prepare --speaker myname
vcl train --speaker myname --batch-size 2

# 4. Generate speech
vcl generate --speaker myname --text "Hello, this is my cloned voice."
```

### Use the Web UI

```bash
vcl ui
# Opens http://127.0.0.1:7860 in your browser
```

## Metal-Specific Configuration

### Batch Size Recommendations

Adjust `--batch-size` for your M-series chip:

| Chip | Batch Size | VRAM Used | Training Time (epoch) |
|------|---|---|---|
| M1 | 1 | ~5 GB | ~20 min |
| M2 | 2 | ~8 GB | ~12 min |
| M3 | 4 | ~12 GB | ~8 min |
| M3 Max | 8 | ~20 GB | ~5 min |

If training crashes with `out of memory`, lower the batch size.

### Compute Type

The installation automatically uses `float32` for Metal (Metal has limited `float16` support). If you override this in config, keep it as `float32`.

### Attention Implementation

Metal works best with `sdpa` (scaled dot-product attention). Flash attention is not supported on Metal; the system automatically falls back to sdpa.

## Troubleshooting

### "Metal available: False"

PyTorch was installed without Metal support. **Reinstall:**
```bash
pip uninstall torch torchvision torchaudio -y
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cpu
python3 -c "import torch; print(torch.backends.mps.is_available())"
```

### Out of Memory During Training

Lower batch size:
```bash
vcl train --speaker myname --batch-size 1
```

Or reduce epochs in `config/default.yaml`:
```yaml
training:
  epochs: 3  # instead of 5
```

### Training is Very Slow

Expected on M1 (see Performance table above). M3 Max is ~3x faster than M1. If your M3 is slow, check:
1. Are you using Rosetta (Intel emulation)? Use native Apple Silicon terminal.
2. Check Activity Monitor → Memory. If swap is high (>10 GB), lower batch size.

### "ffmpeg not found"

Reinstall:
```bash
brew install ffmpeg
```

### Transcription Fails

Ensure `faster-whisper` is installed:
```bash
pip install faster-whisper
```

For CPU-only transcription (slow), use openai-whisper:
```bash
pip install openai-whisper
```

## Migrating from Linux/CUDA

If you have voice checkpoints trained on Linux/CUDA:

1. Copy checkpoints to `outputs/checkpoints/<speaker>/`
2. Run `vcl generate --speaker <speaker> --text "test"` — checkpoints are device-agnostic
3. Generation works directly on Metal; no retraining needed

Checkpoints trained on Metal are compatible with CUDA systems and vice versa.

## Next Steps

- [README.md](./README.md) — Full documentation
- [AGENTS.md](./AGENTS.md) — Development guide
- Web UI at `http://127.0.0.1:7860` when running `vcl ui`

## Support

For macOS-specific issues:

1. Run `vcl check` and paste the full output
2. Check Metal support: `python3 -c "import torch; print(torch.backends.mps.is_available())"`
3. Check PyTorch version: `python3 -c "import torch; print(torch.__version__)"`

---

**Happy voice cloning on your Mac! 🎤**
