# Voice Clone Lab — macOS Apple Silicon Fork

**Full training & generation support for M1/M2/M3 Macs using Metal (MPS) acceleration.**

This is a parallel fork of [tetsuo-ai/voice_clone_lab](https://github.com/tetsuo-ai/voice_clone_lab) optimized for Apple Silicon Macs. It retains 100% feature parity with the original while adding native Metal GPU acceleration and macOS-specific installation/system detection.

## What's Changed from Original

### Device & Compute Enhancements
- ✅ **Auto-detect Metal (MPS)** for Apple Silicon Macs
- ✅ **Automatic compute type selection**: `float32` for Metal/CPU, `float16` for CUDA
- ✅ **Updated system checks** to detect Metal availability and give macOS-specific guidance
- ✅ **Homebrew-aware** installation instructions and fallbacks

### Files Modified
```
src/voice_clone_lab/config.py       → Device auto-detection (Metal/CUDA/CPU)
src/voice_clone_lab/system.py       → Metal detection in vcl check
src/voice_clone_lab/transcribe.py   → fp16 handling for Metal compatibility
INSTALL_MACOS.md                     → Complete macOS setup guide
README_MACOS.md                      → This file
```

### No Breaking Changes
- Original config files work unchanged
- Checkpoints trained on Linux/CUDA work on macOS/Metal and vice versa
- All CLI commands identical to original

## Quick Start (5 minutes)

### Prerequisites
- macOS 12.3+ (M1/M2/M3)
- Python 3.10+ (install via Homebrew or python.org)

### 1. Install Dependencies

```bash
# Via Homebrew (macOS package manager)
brew install python@3.12 ffmpeg git
```

### 2. Create Virtual Environment & Install

```bash
python3.12 -m venv ~/.venv/vcl
source ~/.venv/vcl/bin/activate

# Install PyTorch with Metal support
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cpu

# Clone this fork
git clone https://github.com/YOUR_USERNAME/voice_clone_lab.git
cd voice_clone_lab

# Install Voice Clone Lab
pip install -e '.[ui]'
vcl setup --download
vcl check  # Should show Metal available
```

### 3. Clone Your Voice

```bash
# Provide audio (5–15 min of your voice, clean mono)
vcl run --speaker myvoice --input ~/Recordings/me.wav

# Fix any transcription errors (if any)
vcl transcribe --speaker myvoice --review
# Edit data/voices/myvoice/transcripts/transcripts_review.tsv, then:
vcl transcribe --speaker myvoice --apply-review --force

# Train (use --batch-size 2 on M1, 4 on M2/M3)
vcl prepare --speaker myvoice
vcl train --speaker myvoice --batch-size 2

# Generate
vcl generate --speaker myvoice --text "Hello, I'm alive!"
```

### 4. Web UI (Optional)

```bash
vcl ui  # Opens http://127.0.0.1:7860
```

**That's it.** For detailed setup and troubleshooting, see [INSTALL_MACOS.md](./INSTALL_MACOS.md).

## Performance on Apple Silicon

| Chip | Training Speed | Notes |
|------|---|---|
| M1 8-core | ~2–3× slower than RTX 3090 | ~1h full training; use batch_size=1 |
| M2 | ~1.5–2× slower | ~50m full training; batch_size=2–4 OK |
| M3 8-core | ~1–1.5× slower | ~40m full training; batch_size=4–8 OK |
| M3 Max (12 GPU cores) | ~1× same as RTX 3090 | ~30m full training; batch_size=8+ |

**Generation is real-time on all M-series chips.** Training is slower but acceptable for a one-time 30–90 minute fine-tuning.

## Architecture Support

### Supported
- ✅ Apple Silicon (M1, M1 Pro/Max, M2, M2 Pro/Max, M3, M3 Pro/Max)
- ✅ Metal (MPS) GPU acceleration
- ✅ Full training + generation

### Not Supported (Yet)
- ❌ Intel Macs (x86_64) — Use original repo or run in Linux VM
- ❌ CPU-only on Apple Silicon (very slow; use if Metal fails)

## How Device Detection Works

On startup, the system automatically:

1. Detects your Mac's architecture (Apple Silicon vs. Intel)
2. Checks for Metal availability (`torch.backends.mps.is_available()`)
3. Sets device to `"mps"` if Metal works, else `"cpu"`
4. Sets compute_type to `"float32"` (Metal doesn't support `float16`)
5. Overrides with `--device` flag if you specify one

See `config.py` for the full logic.

## Configuration

### Override Device at Runtime

```bash
# Force CPU (slow, debugging only)
vcl train --speaker myvoice --device cpu

# Force specific device
vcl generate --speaker myvoice --device mps --text "test"
```

### Batch Size Tuning

Edit `config/default.yaml` or use `--batch-size` flag:

```bash
vcl train --speaker myvoice --batch-size 1  # For M1
vcl train --speaker myvoice --batch-size 4  # For M2/M3
```

## Compatibility

### Checkpoints
Checkpoints are **completely device-agnostic**. A checkpoint trained on:
- ✅ CUDA → works on Metal (no retraining needed)
- ✅ Metal → works on CUDA
- ✅ CPU → works everywhere

### Project Structure
Drop in a trained voice from original repo:
```bash
cp -r /path/to/original/data/voices/speaker ./data/voices/
cp -r /path/to/original/outputs/checkpoints/speaker ./outputs/checkpoints/
vcl generate --speaker speaker --text "test"  # Works immediately
```

## Troubleshooting

### Metal Not Available

```bash
python3 -c "import torch; print(torch.backends.mps.is_available())"
```

If this prints `False`, reinstall PyTorch:
```bash
pip uninstall torch torchvision torchaudio -y
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/nightly/cpu
```

### Out of Memory
Lower batch size or reduce epochs:
```bash
vcl train --speaker myvoice --batch-size 1
```

### Transcription Crashes
Ensure `faster-whisper` is installed:
```bash
pip install faster-whisper
```

For full troubleshooting, see [INSTALL_MACOS.md#troubleshooting](./INSTALL_MACOS.md#troubleshooting).

## Development

This fork tracks the original repo. To merge upstream changes:

```bash
git remote add upstream https://github.com/tetsuo-ai/voice_clone_lab.git
git fetch upstream main
git merge upstream/main  # Resolve any conflicts in config.py, system.py
```

## Testing

Run the test suite (CPU only):

```bash
pip install -e '.[dev]'
pytest tests/  # CPU-only, no GPU needed
```

## Contributing

Found a bug? Have improvements?

1. File an issue on this fork (reference macOS or Metal if relevant)
2. Or submit a PR back to the original repo

## What's in This Repository

```
.
├── src/voice_clone_lab/          # Source code (modified for Metal)
│   ├── config.py                 # Device auto-detection
│   ├── system.py                 # Metal detection in checks
│   ├── transcribe.py             # fp16 handling for Metal
│   └── ...                        # All other files unchanged
├── INSTALL_MACOS.md              # macOS setup guide (start here)
├── README_MACOS.md               # This file
├── README.md                      # Original README (also applicable)
├── pyproject.toml                # No changes needed
└── config/default.yaml           # Works as-is; auto-detects device
```

## License

Apache-2.0 — same as original. This fork is a clean derivative with no proprietary code.

## Credits

- **Original:** [tetsuo-ai/voice_clone_lab](https://github.com/tetsuo-ai/voice_clone_lab)
- **Built on:** Qwen3-TTS (Alibaba Qwen), faster-whisper, PyTorch, Gradio
- **Metal/macOS:** Optimizations for PyTorch Metal backend

---

**Questions?** Check [INSTALL_MACOS.md](./INSTALL_MACOS.md) or open an issue.

**Ready to clone your voice? Start with `INSTALL_MACOS.md` →**
